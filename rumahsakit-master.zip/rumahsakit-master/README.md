# rumahsakit
aplikasi rekam medis PHP template simple sidebar 1.0.1
untuk tutorialnya bisa dilihat di 
https://www.youtube.com/playlist?list=PLTagRbmJ8ettXwsd6QJ2D7SO_QV3GSBC8
